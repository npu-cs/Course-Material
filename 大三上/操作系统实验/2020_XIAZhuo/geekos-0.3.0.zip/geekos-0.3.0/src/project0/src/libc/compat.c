#include <conio.h>
#include <stddef.h>

void *Malloc(size_t n)
{
    Print("Malloc not implemented in user mode\n");
    return 0;
}
