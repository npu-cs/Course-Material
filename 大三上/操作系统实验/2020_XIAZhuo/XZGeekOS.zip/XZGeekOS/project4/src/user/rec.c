/*
 * A user mode program which uses deep recursion
 * to test stack growth.
 */

#include <conio.h>
#include <string.h>

void Recurse(int x)
{
	int stuff[512];
	int i;

	if (x == 0)
		return;

	for (i = 0; i < 512; i++)
		stuff[i] = x * i;
	// Print("calling Recurse %d\n", x);
	Recurse(x - 1);
	for (i = 0; i < 512; i++)
	{
		Put_Cursor(25, 0);
		Print("%d", stuff[i]);
	}
}

int main(int argc, char **argv)
{
	/* change recurse to 5-10 to see stack faults without page outs */
	int depth = 512;

	if (argc > 1)
	{
		depth = atoi(argv[1]);
		Print("Depth is %d\n", depth);
	}

	Recurse(depth);

	Print("\nOK\n");

	return 0;
}
